package pt.isec.ans.rascunhos.modelo

object Rascunhos {
    val lista = arrayListOf<Rascunho>()
}