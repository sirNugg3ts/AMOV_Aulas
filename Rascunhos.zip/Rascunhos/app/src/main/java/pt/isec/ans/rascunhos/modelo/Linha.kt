package pt.isec.ans.rascunhos.modelo

import android.graphics.Path

data class Linha(val path : Path, val cor : Int)